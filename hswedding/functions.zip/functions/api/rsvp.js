/**
 * Cloudflare Pages Function — RSVP 中繼站
 * 路徑：部署後會自動變成  https://你的網域/api/rsvp
 *
 * 作用：接收表單送來的資料，在「伺服器端」轉發到 Google Apps Script，
 *       再寫進同一張 Google 試算表。
 *
 * 為什麼要這一層？
 *   中國大陸的防火牆會擋掉「使用者 → Google」的直接連線，
 *   但擋不掉「Cloudflare → Google」（Cloudflare 的伺服器不在牆內）。
 *   所以中國親友先把資料送到 Cloudflare（連得上），
 *   再由 Cloudflare 幫忙轉交給 Google，資料就進得了同一張表。
 *
 * 設定：把下面的 GOOGLE_ENDPOINT 換成你的 Apps Script 網頁應用程式網址（/exec 結尾）。
 *       （目前已填入你先前部署的網址，若日後重新部署換了網址，改這裡即可。）
 */

const GOOGLE_ENDPOINT =
  "https://script.google.com/macros/s/AKfycbwzzjFo2tWGOi1GMf_bjGxwuWwHhTOpSetW1Aax-Tr-QktTNYZCuKD6dNK8nTWvyTmm/exec";

export async function onRequestPost(context) {
  try {
    const body = await context.request.text(); // 原封不動轉發賓客送來的 JSON
    const resp = await fetch(GOOGLE_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body,
    });
    // Apps Script 會 302 轉址到實際回應，fetch 會自動跟隨。
    // 必須檢查 Google 實際回傳的內容，避免試算表沒寫進去卻回報成功。
    const text = await resp.text().catch(() => "");
    let g = null;
    try { g = JSON.parse(text); } catch (_) {}
    if (!resp.ok || !g || g.ok !== true) {
      return json({ ok: false, error: (g && g.error) || ("Google 端回應異常 HTTP " + resp.status) }, 502);
    }
    return json({ ok: true });
  } catch (err) {
    return json({ ok: false, error: String(err) }, 502);
  }
}

// 讓瀏覽器（含跨網域情況）能正常呼叫
export async function onRequestOptions() {
  return new Response(null, {
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    },
  });
}

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
  });
}
